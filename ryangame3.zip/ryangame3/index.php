<?php
session_start();
include_once('db.php'); // Inclua seu arquivo de conexão com o banco de dados
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
}
$_SERVER['page'] = 'index';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>RYANGAME 3</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <?php include('navbar.php'); ?>

    <div id="online-users">
        <h2>Usuários Online</h2>
        <ul id="users-list"></ul>
    </div>

    <script>
        var nick = '<?php echo $nick; ?>';
        var conn = new WebSocket('ws://localhost:8080');
        var usersList = document.getElementById('users-list');

        conn.onopen = function(e) {
            console.log("Connection established!");
            conn.send(JSON.stringify({ type: 'login', nick: nick }));
        };

        conn.onmessage = function(e) {
            var data = JSON.parse(e.data);
            if (data.type === 'update') {
                usersList.innerHTML = '';
                data.nicks.forEach(function(userNick) {
                    if (userNick !== nick) {
                        var li = document.createElement('li');
                        li.textContent = userNick;
                        var button = document.createElement('button');
                        button.textContent = 'Enviar Olá';
                        button.onclick = function() {
                            conn.send(JSON.stringify({ type: 'message', target: userNick }));
                        };
                        li.appendChild(button);
                        usersList.appendChild(li);
                    }
                });
            } else if (data.type === 'message') {
                var response = confirm(data.from + ' pergunta: "Você está bem?"');
                var answer = response ? 'Sim' : 'Não';
                conn.send(JSON.stringify({ type: 'response', sender: data.from, response: answer }));
            } else if (data.type === 'response') {
                alert(data.from + ' respondeu: ' + data.response);
            }
        };

        window.onbeforeunload = function() {
            conn.send(JSON.stringify({ type: 'logout', nick: nick }));
        };
    </script>
</body>
</html>
