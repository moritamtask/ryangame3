<?php
session_start();
include_once('db.php');
if(!isset($_SESSION['username'])){
    header('Location: login.php');
}

$_SERVER['page'] = 'colecao';
include 'cartas.php';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="colecaoStyle.css">
    <title>COLECAO</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<body>
    <?php
        include('navbar.php');
    ?>

    <div class="colecaoMain">
        <h1>COLEÇÃO</h1>
        <?php
            // Consulta para obter as cartas do jogador
            $sqlcards = "SELECT nomeCarta FROM cartas WHERE username = '" . $_SESSION['username'] . "'";
            $consulta = $conexao->query($sqlcards);

            // Verifica se a consulta retornou resultados
            if ($consulta->num_rows > 0) {
                // Armazena os nomes das cartas possuídas pelo jogador
                $cartas_possuídas = array();
                while($row = $consulta->fetch_assoc()) {
                    $cartas_possuídas[] = $row['nomeCarta'];
                }

                // Exibe as cartas que o jogador possui
                foreach ($cartas as $carta) {
                    if (in_array($carta['nomeCarta'], $cartas_possuídas)) {
                        echo "<div class='carta'>";
                        echo "<img src='" . $carta['imagem'] . "' alt='" . $carta['nomeCarta'] . "'><br>";
                        echo $carta['nomeCarta'] . "<br>";
                        
                        // Exibe o ícone apropriado com base no elemento
                        if ($carta['elemento'] == 'fogo') {
                            echo "<span class='material-symbols-outlined' style='color: red; font-size: 2rem;'>local_fire_department</span>";
                        } elseif ($carta['elemento'] == 'gelo') {
                            echo "<span class='material-symbols-outlined' style='color: white; font-size: 2rem;'>ac_unit</span>";
                        } elseif ($carta['elemento'] == 'agua') {
                            echo "<span class='material-symbols-outlined' style='color: blue; font-size: 2rem;'>water_drop</span>";
                        }
                        echo $carta['forca'];
                        echo "</div>";
                    }
                }
            } else {
                echo "Nenhuma carta encontrada para o jogador.";
            }
        ?>
    </div>
</body>
</html>
