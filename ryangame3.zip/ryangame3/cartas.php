<?php
    $cartas = array(
        array("nomeCarta" => "akira", "elemento" => "fogo", "forca" => 15, "preco" => 47000.00, "imagem" => "imgs/akira.png"),
        array("nomeCarta" => "takas", "elemento" => "agua", "forca" => 8, "preco" => 24000.00, "imagem" => "imgs/takas.png"),
        array("nomeCarta" => "leozao", "elemento" => "gelo", "forca" => 12, "preco" => 36000.00, "imagem" => "imgs/leozao.png"),
        array("nomeCarta" => "leonardo", "elemento" => "fogo", "forca" => 5, "preco" => 15000.00, "imagem" => "imgs/leonardo.png"),
        /* array("nomeCarta" => "lelo", "elemento" => "agua", "forca" => 16, "preco" => 50000.00, "imagem" => "imgs/lelo.png"), */
        array("nomeCarta" => "gigi", "elemento" => "gelo", "forca" => 3, "preco" => 9000.00, "imagem" => "imgs/gigi.png"),
        /* array("nomeCarta" => "ryan", "elemento" => "fogo", "forca" => 10, "preco" => 30000.00, "imagem" => "imgs/ryan.png"), */
        /* array("nomeCarta" => "gian", "elemento" => "agua", "forca" => 7, "preco" => 21000.00, "imagem" => "imgs/gian.png"), */
        array("nomeCarta" => "ricardo", "elemento" => "gelo", "forca" => 14, "preco" => 42000.00, "imagem" => "imgs/ricardo.png"),
        array("nomeCarta" => "rikas", "elemento" => "fogo", "forca" => 9, "preco" => 27000.00, "imagem" => "imgs/rikas.png"),
        array("nomeCarta" => "vitu", "elemento" => "agua", "forca" => 2, "preco" => 6000.00, "imagem" => "imgs/vitu.png"),
        array("nomeCarta" => "bitor", "elemento" => "gelo", "forca" => 11, "preco" => 33000.00, "imagem" => "imgs/bitor.png"),
        /* array("nomeCarta" => "fafa", "elemento" => "fogo", "forca" => 6, "preco" => 18000.00, "imagem" => "imgs/fafa.png"), */
        /* array("nomeCarta" => "kenji46", "elemento" => "agua", "forca" => 13, "preco" => 39000.00, "imagem" => "imgs/kenji46.png"), */
        array("nomeCarta" => "kiron", "elemento" => "gelo", "forca" => 4, "preco" => 12000.00, "imagem" => "imgs/kiron.png"),
        array("nomeCarta" => "felidick", "elemento" => "fogo", "forca" => 1, "preco" => 1000.00, "imagem" => "imgs/felidick.png"),
        array("nomeCarta" => "felipinto", "elemento" => "agua", "forca" => 15, "preco" => 45000.00, "imagem" => "imgs/felipinto.png"),
        array("nomeCarta" => "felipenis", "elemento" => "gelo", "forca" => 8, "preco" => 25000.00, "imagem" => "imgs/felipenis.png"),
        /* array("nomeCarta" => "flele", "elemento" => "fogo", "forca" => 12, "preco" => 35000.00, "imagem" => "imgs/flele.png"), */
        array("nomeCarta" => "flex", "elemento" => "agua", "forca" => 5, "preco" => 14000.00, "imagem" => "imgs/flex.png"),
        array("nomeCarta" => "flexshow", "elemento" => "gelo", "forca" => 16, "preco" => 50000.00, "imagem" => "imgs/flexshow.png"),
        array("nomeCarta" => "cuei", "elemento" => "fogo", "forca" => 3, "preco" => 8000.00, "imagem" => "imgs/cuei.png"),
        array("nomeCarta" => "drop", "elemento" => "agua", "forca" => 10, "preco" => 29000.00, "imagem" => "imgs/drop.png"),
        array("nomeCarta" => "danidan", "elemento" => "gelo", "forca" => 7, "preco" => 20000.00, "imagem" => "imgs/danidan.png"),
        array("nomeCarta" => "daniCria", "elemento" => "fogo", "forca" => 14, "preco" => 41000.00, "imagem" => "imgs/daniCria.png"),
        /* array("nomeCarta" => "dardo", "elemento" => "agua", "forca" => 9, "preco" => 26000.00, "imagem" => "imgs/dardo.png"),
        array("nomeCarta" => "beto", "elemento" => "gelo", "forca" => 2, "preco" => 7000.00, "imagem" => "imgs/beto.png"), */
        array("nomeCarta" => "nicolas", "elemento" => "fogo", "forca" => 11, "preco" => 32000.00, "imagem" => "imgs/nicolas.png"),
        array("nomeCarta" => "fegordineo", "elemento" => "agua", "forca" => 6, "preco" => 17000.00, "imagem" => "imgs/fegordineo.png")
    );
?>
