<?php
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require dirname(__DIR__) . '/ryangame3/vendor/autoload.php';

class Chat implements MessageComponentInterface {
    protected $clients;
    protected $nicks;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->nicks = [];
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        $conn->send(json_encode(['type' => 'update', 'nicks' => array_values($this->nicks)]));
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);
        
        switch ($data['type']) {
            case 'login':
                $this->nicks[$from->resourceId] = $data['nick'];
                break;
            case 'logout':
                unset($this->nicks[$from->resourceId]);
                break;
            case 'message':
                $targetNick = $data['target'];
                foreach ($this->clients as $client) {
                    if ($this->nicks[$client->resourceId] === $targetNick) {
                        $client->send(json_encode([
                            'type' => 'message',
                            'from' => $this->nicks[$from->resourceId],
                            'message' => 'Você está bem?'
                        ]));
                    }
                }
                return;
            case 'response':
                $senderNick = $data['sender'];
                foreach ($this->clients as $client) {
                    if ($this->nicks[$client->resourceId] === $senderNick) {
                        $client->send(json_encode([
                            'type' => 'response',
                            'from' => $this->nicks[$from->resourceId],
                            'response' => $data['response']
                        ]));
                    }
                }
                return;
        }

        foreach ($this->clients as $client) {
            $client->send(json_encode(['type' => 'update', 'nicks' => array_values($this->nicks)]));
        }
    }

    public function onClose(ConnectionInterface $conn) {
        unset($this->nicks[$conn->resourceId]);
        $this->clients->detach($conn);

        foreach ($this->clients as $client) {
            $client->send(json_encode(['type' => 'update', 'nicks' => array_values($this->nicks)]));
        }
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $conn->close();
    }
}

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new Chat()
        )
    ),
    8080
);

$server->run();
?>
