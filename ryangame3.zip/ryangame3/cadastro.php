<?php
include_once('db.php');
include_once('cartas.php');

$erro = ""; // Inicializa a variável $erro

if(isset($_POST['submit'])) {
    $username = strtolower($_POST['username']); // Converte username para minúsculas
    $password = $_POST['password'];
    $nick = $_POST['nick'];
    
    // Verifica se username ou nick já existem no banco de dados
    $consulta = mysqli_query($conexao, "SELECT * FROM users WHERE username = '$username' OR nick = '$nick'");
    
    // Verifica se a consulta retornou algum resultado
    if (mysqli_num_rows($consulta) > 0 || $nick == 'bot') {
        $erro = "Usuário ou nick já cadastrado, tente novamente.";
    } else {
        // Hash da senha
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Insere os dados no banco de dados
        $insercao = mysqli_query($conexao, "INSERT INTO users (username, password, nick, lvl, coins) VALUES ('$username', '$hashed_password', '$nick', 1, 50)");
        
        if ($insercao) {
            // Inserção bem-sucedida, selecionar cartas aleatórias
            $cartasSelecionadas = array();
            $precoTotal = 0;
            while (count($cartasSelecionadas) < 3) {
                $carta = $cartas[array_rand($cartas)];
                $novoPrecoTotal = $precoTotal + $carta['preco'];
                if ($novoPrecoTotal <= 50000) {
                    $cartasSelecionadas[] = $carta['nomeCarta'];
                    $precoTotal = $novoPrecoTotal;
                }
            }
            
            // Inserir as cartas selecionadas no banco de dados
            foreach ($cartasSelecionadas as $nomeCarta) {
                mysqli_query($conexao, "INSERT INTO cartas (nomeCarta, username) VALUES ('$nomeCarta', '$username')");
            }
            
            header('Location: login.php');
            exit; // Termina a execução após o redirecionamento
        } else {
            // Ocorreu um erro ao inserir os dados
            $erro = "Erro ao inserir os dados: " . mysqli_error($conexao);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ryanchess Cadastro</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="loginstyle.css">
</head>
<body>
    <div class="menuLogin">
        <div class="form">
            <img src="imgs/loginIMG.png" alt="">
            <h1>Cadastro</h1>
            <form method="post" action="cadastro.php">
                <input type="text" name="username" id="username" placeholder="username">
                <input type="password" name="password" id="password" placeholder="password">
                <input type="text" name="nick" id="nick" placeholder="nick">
                <?php
                    if(!empty($erro)) {
                        echo "<p>$erro</p>";
                    }
                ?>
                <button type="submit" name="submit">
                    <span class="material-symbols-outlined">
                        arrow_forward
                    </span>
                </button>
            </form>
            <a href="login.php">Já tenho conta (Fazer Login)</a>
        </div>
        <div class="background">
        </div>
    </div>
</body>
</html>
