<?php
    include_once('db.php');
    $stmt = $conexao->prepare("SELECT coins,nick,lvl FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $coins = $row['coins'];
    $nick = $row['nick'];
    $lvl = $row['lvl'];
?>

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="stylesheet" href="navstyle.css">

<div class="navbar">
    <div class="play">
        <img src="imgs/logoGame.png" alt="">
        <a href="index.php" class="<?php echo ($_SERVER['page'] == 'index') ? 'jogarActive' : ''; ?>">JOGAR</a>
    </div>
    <div class="leftBar">
        <div class="options">
            <a href="colecao.php" class="<?php echo ($_SERVER['page'] == 'colecao') ? 'active' : ''; ?>">
                <span class="material-symbols-outlined">
                    dashboard
                </span>
            </a>
            <a href="loja.php" class="<?php echo ($_SERVER['page'] == 'loja') ? 'active' : ''; ?>">
                <span class="material-symbols-outlined">
                    store
                </span>
            </a>
            <h2>$<?php echo htmlspecialchars($coins); ?></h2>
        </div>
        <div class="profileDiv">
            <a href="perfil.php" class="<?php echo ($_SERVER['page'] == 'perfil') ? 'active' : ''; ?>">
                <span class="material-symbols-outlined">
                    account_circle
                </span>
            </a>
        </div>
        <div class="status">
            <h4><?php echo htmlspecialchars($nick); ?></br>LVL: <?php echo htmlspecialchars($lvl); ?></h4>
        </div>
    </div>
    
</div>
