<?php
session_start();

// Destruir a sessão existente, se houver
session_destroy();

$erro = '';

if (isset($_POST['submit'])) {
    if (!empty($_POST['username']) && !empty($_POST['password'])) {
        include_once('db.php');

        $username = strtolower($_POST['username']); // Converte username para minúsculas
        $password = $_POST['password'];

        // Evite SQL Injection usando prepared statements
        $stmt = $conexao->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows < 1) {
            $erro = 'Login não encontrado, tente novamente ou cadastre-se';
        } else {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                session_start();
                $_SESSION['username'] = $username;
                header("Location: index.php");
                exit();
            } else {
                $erro = 'Senha incorreta';
            }
        }
    } else {
        $erro = 'Preencha todos os campos';
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ryanchess LOGIN</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="loginstyle.css">
</head>
<body>
    <div class="menuLogin">
        <div class="form">
            <img src="imgs/loginIMG.png" alt="">
            <h1>Login</h1>
            <form action="login.php" method="post">
                <input type="text" name="username" id="username" placeholder="username">
                <input type="password" name="password" id="password" placeholder="password">
                <?php
                    if (!empty($erro)) {
                        echo "<p>$erro</p>";
                    }
                ?>
                <button type="submit" name="submit">
                    <span class="material-symbols-outlined">
                        arrow_forward
                    </span>
                </button>
            </form>
            <a href="cadastro.php">Não tenho conta (Cadastrar)</a>
        </div>

        <div class="background">
        </div>
    </div>
</body>
</html>
